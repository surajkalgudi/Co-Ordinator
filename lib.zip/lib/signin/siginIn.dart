import 'package:admin/signin/confirm.dart';
import 'package:flutter/material.dart';
import 'package:flutter_login/flutter_login.dart';
import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:amplify_auth_cognito/amplify_auth_cognito.dart';
import 'package:flutter/material.dart';

// import 'package:admin/amplifyconfiguration.dart';
//
//
//
// class SignIn extends StatefulWidget {
//   const SignIn({Key? key}) : super(key: key);
//
//   @override
//   State<SignIn> createState() => _SignInState();
// }
//
// class _SignInState extends State<SignIn> {
//   late LoginData _data;
//
//   Future<String> _onLogin(BuildContext context,LoginData data) async {
//     print(data);
//     return "";
//   }
//
//     Future<String> _signUp(BuildContext context,LoginData data) async{
//       print(data);
//       return "";
//
//     }
//   // Create a boolean for checking the sign up status
//   bool isSignUpComplete = false;
//
//   // Future<String?>? _signUpUser(BuildContext context,LoginData data) async {
//   //   try {
//   //     final userAttributes = <CognitoUserAttributeKey, String>{
//   //       CognitoUserAttributeKey.email: data.name.toString(),
//   //
//   //     };
//   //     final result = await Amplify.Auth.signUp(
//   //       username: data.name.toString(),
//   //       password: data.password.toString(),
//   //       options: CognitoSignUpOptions(userAttributes: userAttributes),
//   //     );
//   //     _data=data;
//   //     setState(() {
//   //       isSignUpComplete = result.isSignUpComplete;
//   //       Navigator.push(context,
//   //         MaterialPageRoute(builder: (context) => ConfirmScreen(data:_data, ),),);
//   //     });
//   //   } on AuthException catch (e) {
//   //     safePrint(e.message);
//   //   }
//   //   throw 'There was a error signing up. Please try again';
//   // }
//
//
//   @override
//   Widget build(BuildContext context) {
//     return FlutterLogin(
//       logo: 'assets/images/logo.png',
//       onLogin: (LoginData data) => _onLogin(context,data),
//       onRecoverPassword: (_) => Future.value(''),
//        onSignup:(LoginData data)=>_signUpUser(context,data),
//       theme: LoginTheme(
//         primaryColor: Theme.of(context).primaryColor,
//       ),
//       onSubmitAnimationCompleted: (){
//         Navigator.push(context,
//             MaterialPageRoute(builder: (context) => ConfirmScreen(data:_data, ),),);
//       },
//     );
//   }
// }

LoginData _data;
bool _isSignedIn = false;

Future<String?> _onLogin(LoginData data) async {
  try {
    final res = await Amplify.Auth.signIn(
      username: data.name,
      password: data.password,
    );

    _isSignedIn = res.isSignedIn;
  } on AuthException catch (e) {
    if (e.message.contains('already a user which is signed in')) {
      await Amplify.Auth.signOut();
      return 'Problem logging in. Please try again.';
    }

    return '${e.message} - ${e.recoverySuggestion}';
  }
}

Future<String?> _onRecoverPassword(BuildContext context, String email) async {
  try {
    final res = await Amplify.Auth.resetPassword(username: email);

    if (res.nextStep.updateStep == 'CONFIRM_RESET_PASSWORD_WITH_CODE') {
      Navigator.of(context).pushReplacementNamed(
        '/confirm-reset',
        arguments: LoginData(name: email, password: ''),
      );
    }
  } on AuthException catch (e) {
    return '${e.message} - ${e.recoverySuggestion}';
  }
}

Future<String?> _onSignup(LoginData data) async {
  try {
    await Amplify.Auth.signUp(
      username: data.name,
      password: data.password,
      options: CognitoSignUpOptions(userAttributes: {
        
      }),
    );

    _data = data;
  } on AuthException catch (e) {
    return '${e.message} - ${e.recoverySuggestion}';
  }
}

@override
Widget build(BuildContext context) {
  return FlutterLogin(
    title: 'Welcome',
    onLogin: _onLogin,
    onRecoverPassword: (String email) => _onRecoverPassword(context, email),
    onSignup: _onSignup,
    theme: LoginTheme(
      primaryColor: Theme.of(context).primaryColor,
    ),
    onSubmitAnimationCompleted: () {
      Navigator.of(context).pushReplacementNamed(
        _isSignedIn ? '/dashboard' : '/confirm',
        arguments: _data,
      );
    },
  );
}
}
